<div class="controle-volume">
  <button onclick="alterarVolume(0.1)">Volume +</button>
  <button onclick="alterarVolume(-0.1)">Volume -</button>
</div>
